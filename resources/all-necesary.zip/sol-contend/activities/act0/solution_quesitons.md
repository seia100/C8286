
En base de la aventura experimentada en la actividad, responda las siguientes preguntas:
1. **En tus propias palabras, usando analogías, explica qué es un contenedor**
  * 
