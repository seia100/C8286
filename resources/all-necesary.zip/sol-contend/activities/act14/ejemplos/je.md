
# important library 

* https://www.geeksforgeeks.org/what-is-message-buffering/

* https://www.cloudflare.com/es-es/learning/video/what-is-buffering/

* https://medium.com/@emmanuelcoronacarrillo/algoritmo-de-anillo-elecci%C3%B3n-distribuida-64f4fd29eceb
* 
## Middlware
* https://aws.amazon.com/es/what-is/middleware/

## ALgoritmo de eleccion
* https://www.goconqr.com/es/mapamental/8212700/algoritmo-de-eleccion

## Algortimos de sincronizacion de relojes
https://dev.to/martinnacimiento/algoritmos-de-sincronizacion-de-relojes-56e8
