Asignacion de tareas: IO, Luis Arenas el tema o pregunta 6 relacionado a seguridad.


