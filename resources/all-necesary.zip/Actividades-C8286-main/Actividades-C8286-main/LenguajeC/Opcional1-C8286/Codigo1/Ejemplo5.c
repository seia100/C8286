#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define VERSION "2.3.4"

#define LOG_ERROR(format, ...) \
  fprintf(stderr, format, __VA_ARGS__)

int main(int argc, char** argv) {

  if (argc < 3) {
    LOG_ERROR("Invalido numero de argumentos para esta version %s\n.",
            VERSION);
    exit(1);
  }

  if (strcmp(argv[1], "-n") != 0) {
    LOG_ERROR("%s es un param incorrecto en el indice %d para la version %s.",
            argv[1], 1, VERSION);
    exit(1);
  }

  // ...

  return 0;
}