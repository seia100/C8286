#include <stdio.h>
#define CODE \
printf("%d\n", i);

int main(int argc, char** argv) {
  CODE
  return 0;
}