typedef struct {
  int x;
  int y;
} punto_t;

typedef struct {
  punto_t centro;
  int radio;
} circulo_t;

typedef struct {
  punto_t inicio;
  punto_t final;
} linea_t;
