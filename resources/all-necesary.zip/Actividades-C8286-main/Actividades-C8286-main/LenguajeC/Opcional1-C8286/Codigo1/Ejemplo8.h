#ifndef EXAMPLE_8_H
#define EXAMPLE_8_H

void say_hello();
int read_age();

#endif
